cd ~/Work/Notes-Frequencies/Source_Code/
bash -n FRETBOARDNF 
