date +%A-%B%e-%I:%M >> bmark.txt
command time --format %P%M ./FRETBOARDNF
