/* Fretboard Notes & Frequencies.
  Copyright (C) 2010-2022  Gary J. Teixeira Jr.

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.#
  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

  You may contact the developer of this program at:  ambientmine@protonmail.com
*/

#include <stdio.h>
#include <string.h> 
int main(void)
{
  char tuning[2];

  /* GNU GPL Version 3 Info */
  printf ("Fretboard Notes & Frequencies\n");
  printf ("Copyright (C) 2010-2021  Gary J. Teixeira Jr.\n");
  printf ("\n");
  printf ("This program is free software: you can redistribute it and/or modify\n");
  printf ("it under the terms of the GNU General Public License as published by\n");
  printf ("the Free Software Foundation, either version 3 of the License, or\n");
  printf ("(at your option) any later version.\n");
  printf ("\n");
  printf ("This program is distributed in the hope that it will be useful, \n");
  printf ("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
  printf ("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the\n");
  printf ("GNU General Public License for more details.\n");
  printf ("\n");
  printf ("You should have received a copy of the GNU General Public License\n");
  printf ("along with this program.  If not, see <http://www.gnu.org/licenses/>.\n");
  printf ("\n");
  printf ("You may contact the developer of this program at:  ambientmine@protonmail.com\n");
  printf ("\n");

  printf ("Please Seledct Guitar Tuning\n\n");
  printf ("1. -24 Frets    ");
  scanf("%s", tuning);
  if (tuning == "1")
	{
	  printf ("	 S     6           5          4          3           2           1\n\n"};
	
	  printf ("F  0  E1  20.60   A2  27.5   D2  36.7   G2  48.99   B3  61.73   E3  82.4\n");
	    /*  1  F1  21.82   Bb2 29.13  D#2 38.89  G#2 51.91   C3  65.4    F3  87.3\n
	    2  F#1 23.12   B2  30.86  E2  41.2   A3  55      C#3 69.29   F#3 92.49\n
	    3  G1  24.49   C2  32.7   F2  43.65  Bb3 58.27   D3  73.41   G3  97.99\n
	    4  G#1 25.95   C#2 34.64  F#2 46.24  B3  61.73   D#3 77.78   G#3 103.82\n
	    5  A2  27.5    D2  36.7   G2  48.99  C3  65.40   E3  82.4    A4  110\n
	    6  Bb2 29.13   D#2 38.89  G#2 51.91  C#3 69.29   F3  87.3    Bb4 116.54\n
	    7  B2  30.86   E2  41.2   A3  55     D3  73.41   F#3 92.49   B4  123.47\n
	    8  C2  32.7    F2  43.65  Bb3 58.27  D#3 77.781  G3  97.99   C4  130.81\n
	    9  C#2 34.64   F#2 46.24  B3  61.73  E3  82.40   G#3 103.82  C#4 138.59\n
	    10 D2  36.7    G2  48.99  C3  65.40  F3  87.30   A4  110     D4  146.83\n
	    11 D#2 38.89   G#2 51.91  C#3 69.29  F#3 92.49   Bb4 116.54  D#4 155.56\n
	    12 E2  41.2    A3  55     D3  73.41  G3  97.99   B4  123.47  E4  164.81\n
	    13 F2  43.65   Bb3 58.27  D#3 77.78  G#3 103.82  C4  130.81  F4  174.61\n
	    14 F#2 46.24   B3  61.73  E3  82.4   A4  110     C#4 138.59  F#4 184.99\n
	    15 G2  48.9    C3  65.40  F3  87.3   Bb4 116.54  D4  146.83  G4  195.99\n
	    16 G#2 51.91   C#3 69.29  F#3 92.49  B4  123.47  D#4 155.56  G#4 207.65\n
	    17 A3  55      D3  73.41  G3  97.99  C4  130     E4  164.81  A5  220\n
	    18 Bb3 58.27   D#3 77.78  G#3 103.82 C#4 138.59  F4  174.61  Bb5 233.08\n
	    19 B3  61.73   E3  82.4   A4  110    D4  146.83  F#4 184.99  B5  246.94\n
	    20 C3  65.40   F3  87.3   Bb4 116.54 D#4 155.56  G4  195.99  C5  261.62\n
	    21 C#2 69.29   F#3 92.49  B4  123.47 E4  164.81  G#4 207.65  C#5 277.18\n
	    22 D3  73.41   G3  97.99  C4  130.81 F4  174.61  A5  220     D5  293.66\n
	    23 D#3 77.78   G#3 103.82 C#4 138.59 F#4 184.99  Bb5 233.08  D#5 311.12\n
	    24 E3  82.4    A4  110    D4  146.83 G4  195.99  B5  246.94  E5  329.62\n"); */
    	}
	else if (tuning == "2")
	{

         }
	else
	  {
	printf ("Option not yet implemeted\n");
	  }
	return 0;
}
