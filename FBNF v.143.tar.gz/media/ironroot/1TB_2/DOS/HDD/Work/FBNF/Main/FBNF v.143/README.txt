# fbnf
   Fretboard Notes & Frequencies (FBNF) is a program that shows you notes 
and frequencies for your fretboard, based on your tuning.
It currently only supports 6-String guitars, but will support 7-8 string guitars
and 4-6 string basses in the future.
